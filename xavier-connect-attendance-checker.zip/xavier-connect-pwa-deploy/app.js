// Semester 1 timetable transcribed from the student's supplied class schedule.
const semesterOneSchedule={
 MON:[['9:10 AM','VAC-1'],['10:00 AM','AC-1'],['10:50 AM','SEC-1'],['11:40 AM','MJ-1'],['12:30 PM','IKS-1']],
 TUE:[['9:10 AM','VAC-1'],['10:00 AM','AC-1'],['10:50 AM','—'],['11:40 AM','MJ-1'],['12:30 PM','—']],
 WED:[['9:10 AM','VAC-1'],['10:00 AM','AC-1'],['10:50 AM','SEC-1'],['11:40 AM','MJ-1'],['12:30 PM','IKS-1']],
 THU:[['9:10 AM','AEC-1'],['10:00 AM','MDC-1'],['10:50 AM','—'],['11:40 AM','MJ-1'],['12:30 PM','—']],
 FRI:[['9:10 AM','AEC-1'],['10:00 AM','MDC-1'],['10:50 AM','SEC-1'],['11:40 AM','MJ-1'],['12:30 PM','IKS-1']],
 SAT:[['9:10 AM','AEC-1'],['10:00 AM','MDC-1'],['10:50 AM','LTM'],['11:40 AM','—'],['12:30 PM','—']]
};
const subjectColors={'VAC-1':'blue','AC-1':'green','SEC-1':'gold','MJ-1':'plain','IKS-1':'cyan','AEC-1':'red','MDC-1':'purple','LTM':'violet'};
const list=document.getElementById('scheduleList');
function renderSchedule(day='MON'){
 if(!list)return;
 list.innerHTML=semesterOneSchedule[day].map(([time,subject],i)=>{
  const free=subject==='—';
  return `<article class="period-card ${free?'free-period':''}"><div class="period-index">0${i+1}</div><div class="period-info"><span class="period-time">${time}</span><strong class="subject-pill ${subjectColors[subject]||''}">${subject}</strong></div><span class="period-state">${free?'NO CLASS LISTED':'CLASS'}</span></article>`;
 }).join('');
}
document.querySelectorAll('.day-tab').forEach(button=>button.addEventListener('click',()=>{
 document.querySelectorAll('.day-tab').forEach(tab=>{const active=tab===button;tab.classList.toggle('active',active);tab.setAttribute('aria-selected',String(active));});
 renderSchedule(button.dataset.day);
}));
renderSchedule();
// Highlight the selected bottom navigation item while navigating sections.
document.querySelectorAll('.bottom-nav a').forEach(a=>a.addEventListener('click',()=>{document.querySelectorAll('.bottom-nav a').forEach(x=>x.classList.toggle('selected',x===a));}));

// The college portal does not expose a verified public prefill interface.
// Keep entered values only in the form and open the official portal; never store or transmit them here.
const attendanceForm=document.getElementById('attendanceForm');
if(attendanceForm){attendanceForm.addEventListener('submit',event=>{
 event.preventDefault();
 const hint=document.getElementById('attendanceHint');
 const popup=window.open('https://sxcran.ac.in/Student/AttendanceSummary','_blank','noopener,noreferrer');
 if(!popup){hint.textContent='Pop-up blocked. Please allow pop-ups or use the official portal link below.';return;}
 hint.textContent='Official portal opened. Enter your Form Number and Semester there; the fields above are not automatically transferred.';
});}
