# Xavier Connect — Attendance Edition

A premium navy-and-gold installable web app for quick access to St. Xavier's College, Ranchi attendance portal, plus the supplied Semester 1 timetable and student-community preview.

## Attendance privacy and limitations
- The attendance form is a local convenience/reminder only. It does not save or transmit the form number, semester, or date.
- Submitting opens the official college attendance page: https://sxcran.ac.in/Student/AttendanceSummary
- The college portal does not provide a verified public prefill/API interface in this project, so students must enter their details on the official portal themselves.
- Attendance figures are never fabricated or scraped by this app.
- Group chat is a preview until the backend is deployed and the login/membership flow is connected.

## Publish
Upload the contents of this folder to an HTTPS static host (for example GitHub Pages). Ensure `index.html` is at the site root. Then open the HTTPS site in Chrome on Android and choose **Install app** / **Add to Home screen**.
